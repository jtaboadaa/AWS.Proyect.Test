package com.example.myapplication;

public class Constants {

    private static final String ROOT_URL = "http://34.193.232.152/phpmyadmin/";
    public static final String URL_REGISTER = ROOT_URL+"index.php";
}
